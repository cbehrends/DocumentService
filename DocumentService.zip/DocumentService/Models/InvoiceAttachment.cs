﻿using System;
using System.Collections.Generic;


namespace DocumentService.Models
{
    public class InvoiceAttachment
    {
        public string DocumentPath { get; set; }
    }
}